num1=1.5
num2=6.3
sum=num1+num2
print('the sum of {0}and{1}is{2}'.format(num1,num2,sum))